from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

from build_act01_centerlocked_v11 import (
    BACKGROUND_RGB,
    CANVAS,
    FRAME_DURATIONS_MS,
    TARGET_BASELINE_Y,
    TARGET_CENTER_X,
    detect_boot_anchor,
    foreground_bbox,
    make_contact_sheet,
    save_gif,
)


PIVOT_Y = 178
FOOT_GUIDE_RGB = (244, 154, 36)
CENTER_GUIDE_RGB = (31, 196, 214)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def smoothstep(value: float) -> float:
    value = max(0.0, min(1.0, value))
    return value * value * (3.0 - 2.0 * value)


def warp_lower_body(
    frame: Image.Image,
    source_left: float,
    source_right: float,
    target_left: float,
    target_right: float,
) -> Image.Image:
    source = np.asarray(frame.convert("RGBA"))
    result = source.copy()
    left_delta = target_left - source_left
    right_delta = target_right - source_right

    for y in range(PIVOT_Y + 1, CANVAS):
        t = smoothstep((y - PIVOT_Y) / (TARGET_BASELINE_Y - PIVOT_Y))
        for x in range(CANVAS):
            delta = left_delta if x < TARGET_CENTER_X else right_delta
            source_x = int(round(x - delta * t))
            source_x = max(0, min(CANVAS - 1, source_x))
            result[y, x] = source[y, source_x]
    return Image.fromarray(result, "RGBA")


def translate(frame: Image.Image, shift_x: int, shift_y: int) -> Image.Image:
    result = Image.new("RGBA", (CANVAS, CANVAS), (0, 0, 0, 0))
    result.alpha_composite(frame, (shift_x, shift_y))
    return result


def make_preview(
    frame: Image.Image,
    target_left: float,
    target_right: float,
    guides: bool,
) -> Image.Image:
    preview = Image.new("RGBA", (CANVAS, CANVAS), BACKGROUND_RGB + (255,))
    if guides:
        draw = ImageDraw.Draw(preview)
        draw.line(
            [(TARGET_CENTER_X, 0), (TARGET_CENTER_X, CANVAS - 1)],
            fill=CENTER_GUIDE_RGB + (255,),
            width=1,
        )
        for x in (int(round(target_left)), int(round(target_right))):
            draw.line(
                [(x, TARGET_BASELINE_Y - 10), (x, TARGET_BASELINE_Y + 10)],
                fill=FOOT_GUIDE_RGB + (255,),
                width=1,
            )
            draw.line(
                [(x - 3, TARGET_BASELINE_Y + 6), (x + 3, TARGET_BASELINE_Y + 6)],
                fill=FOOT_GUIDE_RGB + (255,),
                width=1,
            )
    preview.alpha_composite(frame)
    return preview.convert("RGB")


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: build_act01_fixedfeet_v12.py INPUT_FRAMES OUTPUT_DIR")

    input_dir = Path(sys.argv[1]).resolve()
    output_dir = Path(sys.argv[2]).resolve()
    transparent_dir = output_dir / "frames_transparent"
    preview_dir = output_dir / "frames_preview"
    check_dir = output_dir / "frames_fixedfeet_check"
    for directory in (transparent_dir, preview_dir, check_dir):
        directory.mkdir(parents=True, exist_ok=True)

    input_paths = sorted(input_dir.glob("ACT01_frame_*.png"))
    if len(input_paths) != 10:
        raise RuntimeError(f"Expected 10 input frames, found {len(input_paths)}")
    source_frames = [Image.open(path).convert("RGBA") for path in input_paths]

    first_anchor = detect_boot_anchor(source_frames[0])
    target_left, target_right = first_anchor["boot_centers_x"]
    target_midpoint = (target_left + target_right) / 2.0

    transparent_frames: list[Image.Image] = []
    preview_frames: list[Image.Image] = []
    check_frames: list[Image.Image] = []
    metrics: list[dict] = []

    for index, source_frame in enumerate(source_frames, start=1):
        before = detect_boot_anchor(source_frame)
        if index == 10 and transparent_frames:
            # Close the loop on the exact same planted stance and idle drawing.
            registered = transparent_frames[0].copy()
        else:
            warped = warp_lower_body(
                source_frame,
                before["boot_centers_x"][0],
                before["boot_centers_x"][1],
                target_left,
                target_right,
            )
            after_warp = detect_boot_anchor(warped)
            shift_x = int(round(target_midpoint - after_warp["feet_center_x"]))
            shift_y = int(round(TARGET_BASELINE_Y - after_warp["foot_baseline_y"]))
            registered = translate(warped, shift_x, shift_y)
        after = detect_boot_anchor(registered)

        preview = make_preview(registered, target_left, target_right, guides=False)
        check = make_preview(registered, target_left, target_right, guides=True)
        transparent_path = transparent_dir / f"ACT01_frame_{index:02d}.png"
        preview_path = preview_dir / f"ACT01_frame_{index:02d}.png"
        check_path = check_dir / f"ACT01_frame_{index:02d}.png"
        registered.save(transparent_path)
        preview.save(preview_path)
        check.save(check_path)

        left, right = after["boot_centers_x"]
        bbox = foreground_bbox(np.asarray(registered)[..., 3])
        metrics.append(
            {
                "frame": index,
                "duration_ms": FRAME_DURATIONS_MS[index - 1],
                "source_boot_centers_x": [
                    round(value, 2) for value in before["boot_centers_x"]
                ],
                "boot_centers_x": [round(left, 2), round(right, 2)],
                "left_foot_deviation_px": round(left - target_left, 2),
                "right_foot_deviation_px": round(right - target_right, 2),
                "feet_center_x": round(after["feet_center_x"], 2),
                "stance_width_px": round(right - left, 2),
                "foot_baseline_y": after["foot_baseline_y"],
                "foreground_bbox": list(bbox),
                "inside_canvas": (
                    bbox[0] >= 0 and bbox[1] >= 0
                    and bbox[2] <= CANVAS - 1 and bbox[3] <= CANVAS - 1
                ),
                "transparent_sha256": sha256(transparent_path),
            }
        )
        transparent_frames.append(registered)
        preview_frames.append(preview)
        check_frames.append(check)

    gif_path = output_dir / "ACT01_斜劈_10帧_50pct双脚固定_审核版V1.2.gif"
    check_gif_path = output_dir / "ACT01_斜劈_10帧_双脚固定验证V1.2.gif"
    contact_path = output_dir / "ACT01_斜劈_10帧总览_双脚固定V1.2.png"
    check_contact_path = output_dir / "ACT01_斜劈_10帧双脚固定验证总览V1.2.png"
    save_gif(preview_frames, gif_path)
    save_gif(check_frames, check_gif_path)
    make_contact_sheet(preview_frames).save(contact_path)
    make_contact_sheet(check_frames).save(check_contact_path)

    max_left = max(abs(frame["left_foot_deviation_px"]) for frame in metrics)
    max_right = max(abs(frame["right_foot_deviation_px"]) for frame in metrics)
    report = {
        "input_frames": str(input_dir),
        "canvas": [CANVAS, CANVAS],
        "frame_count": 10,
        "durations_ms": FRAME_DURATIONS_MS,
        "loop_duration_ms": sum(FRAME_DURATIONS_MS),
        "target_body_fill": "50%",
        "foot_reference": "frame 01 individual boot centers",
        "target_left_foot_x": round(target_left, 2),
        "target_right_foot_x": round(target_right, 2),
        "target_centerline_x": round(target_midpoint, 2),
        "target_baseline_y": TARGET_BASELINE_Y,
        "lower_body_warp_pivot_y": PIVOT_Y,
        "max_left_foot_deviation_px": max_left,
        "max_right_foot_deviation_px": max_right,
        "max_either_foot_deviation_px": max(max_left, max_right),
        "all_individual_feet_within_2px": max(max_left, max_right) <= 2.0,
        "all_baselines_locked": all(
            frame["foot_baseline_y"] == TARGET_BASELINE_Y for frame in metrics
        ),
        "all_inside_canvas": all(frame["inside_canvas"] for frame in metrics),
        "frame_10_exact_frame_01": (
            metrics[9]["transparent_sha256"]
            == metrics[0]["transparent_sha256"]
        ),
        "gif": str(gif_path),
        "gif_sha256": sha256(gif_path),
        "fixedfeet_check_gif": str(check_gif_path),
        "fixedfeet_check_gif_sha256": sha256(check_gif_path),
        "contact_sheet": str(contact_path),
        "contact_sheet_sha256": sha256(contact_path),
        "frames": metrics,
    }
    report_path = output_dir / "ACT01_V1.2_双脚固定结构检查.json"
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

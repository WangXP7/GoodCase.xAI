from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw


CANVAS = 256
GRID_COLUMNS = 5
GRID_ROWS = 2
TARGET_BODY_HEIGHT = 128
TARGET_CENTER_X = 128
TARGET_BASELINE_Y = 224
BACKGROUND_RGB = (231, 225, 214)
CENTERLINE_RGB = (31, 196, 214)
FRAME_DURATIONS_MS = [80, 80, 80, 70, 70, 70, 80, 100, 80, 100]
ROW_MAJOR_ORDER = list(range(10))
LEGACY_CONTINUOUS_ARC_ORDER = [0, 1, 2, 3, 5, 4, 6, 7, 8, 0]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def crop_grid_cell(sheet: Image.Image, index: int) -> Image.Image:
    row, column = divmod(index, GRID_COLUMNS)
    left = round(column * sheet.width / GRID_COLUMNS)
    right = round((column + 1) * sheet.width / GRID_COLUMNS)
    top = round(row * sheet.height / GRID_ROWS)
    bottom = round((row + 1) * sheet.height / GRID_ROWS)
    return sheet.crop((left, top, right, bottom))


def chroma_to_rgba(cell: Image.Image) -> Image.Image:
    rgb_image = cell.convert("RGB").resize(
        (CANVAS, CANVAS), Image.Resampling.NEAREST
    )
    rgb = np.asarray(rgb_image)
    red = rgb[..., 0].astype(np.int16)
    green = rgb[..., 1].astype(np.int16)
    blue = rgb[..., 2].astype(np.int16)
    magenta = (
        (red > 205)
        & (blue > 145)
        & (green < 125)
        & ((red - green) > 95)
        & ((blue - green) > 75)
    )
    alpha = np.where(magenta, 0, 255).astype(np.uint8)
    return Image.fromarray(np.dstack((rgb, alpha)).astype(np.uint8), "RGBA")


def foreground_bbox(alpha: np.ndarray) -> tuple[int, int, int, int]:
    ys, xs = np.nonzero(alpha > 0)
    if len(xs) == 0:
        raise RuntimeError("No foreground detected")
    return int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())


def scale_full_canvas(frame: Image.Image, scale: float) -> Image.Image:
    size = max(1, int(round(CANVAS * scale)))
    return frame.resize((size, size), Image.Resampling.NEAREST)


def _two_cluster_centers(score: np.ndarray) -> list[float]:
    xs = np.nonzero(score > 0)[0].astype(np.float64)
    if len(xs) < 2:
        raise RuntimeError("Insufficient lower-body pixels for boot detection")
    weights = np.square(score[xs.astype(np.int32)].astype(np.float64))

    cumulative = np.cumsum(weights)
    total = cumulative[-1]
    centers = np.array(
        [
            xs[np.searchsorted(cumulative, total * 0.25)],
            xs[np.searchsorted(cumulative, total * 0.75)],
        ],
        dtype=np.float64,
    )
    for _ in range(20):
        distances = np.abs(xs[:, None] - centers[None, :])
        labels = distances.argmin(axis=1)
        updated = centers.copy()
        for cluster in range(2):
            keep = labels == cluster
            if keep.any():
                updated[cluster] = np.average(xs[keep], weights=weights[keep])
        if np.allclose(updated, centers, atol=1e-6):
            break
        centers = updated
    return sorted(float(value) for value in centers)


def detect_boot_anchor(frame: Image.Image) -> dict:
    rgba = np.asarray(frame.convert("RGBA"))
    rgb = rgba[..., :3]
    alpha = rgba[..., 3]
    x0, y0, x1, y1 = foreground_bbox(alpha)
    yy, xx = np.indices(alpha.shape)
    brightness = rgb.max(axis=2)

    # Boots are the two broad, dark armor masses in the lower part of the
    # silhouette. Thin bright sword pixels receive little or no weight.
    lower_start = max(y0, y1 - max(28, int(round((y1 - y0 + 1) * 0.34))))
    candidate = (
        (alpha > 0)
        & (yy >= lower_start)
        & (yy <= y1)
        & (brightness < 205)
    )
    column_score = candidate.sum(axis=0)
    centers = _two_cluster_centers(column_score)
    baselines: list[int] = []
    half_window = max(9, int(round(CANVAS * 0.055)))
    for center in centers:
        left = max(0, int(round(center)) - half_window)
        right = min(alpha.shape[1], int(round(center)) + half_window + 1)
        local = candidate[:, left:right]
        local_y, local_x = np.nonzero(local)
        if len(local_x) == 0:
            raise RuntimeError("Empty boot region")
        baselines.append(int(local_y.max()))
    return {
        "boot_centers_x": centers,
        "feet_center_x": float(sum(centers) / 2.0),
        "foot_baseline_y": int(max(baselines)),
        "detection_lower_start_y": int(lower_start),
        "foreground_bbox": [x0, y0, x1, y1],
    }


def translate_to_canvas(
    frame: Image.Image, shift_x: int, shift_y: int
) -> Image.Image:
    canvas = Image.new("RGBA", (CANVAS, CANVAS), (0, 0, 0, 0))
    canvas.alpha_composite(frame, (shift_x, shift_y))
    return canvas


def make_preview(frame: Image.Image, centerline: bool = False) -> Image.Image:
    preview = Image.new("RGBA", (CANVAS, CANVAS), BACKGROUND_RGB + (255,))
    if centerline:
        draw = ImageDraw.Draw(preview)
        draw.line(
            [(TARGET_CENTER_X, 0), (TARGET_CENTER_X, CANVAS - 1)],
            fill=CENTERLINE_RGB + (255,),
            width=1,
        )
        draw.line(
            [(TARGET_CENTER_X - 4, TARGET_BASELINE_Y + 8),
             (TARGET_CENTER_X + 4, TARGET_BASELINE_Y + 8)],
            fill=CENTERLINE_RGB + (255,),
            width=1,
        )
    preview.alpha_composite(frame)
    return preview.convert("RGB")


def build_palette(frames: list[Image.Image]) -> Image.Image:
    strip = Image.new("RGB", (CANVAS * len(frames), CANVAS), BACKGROUND_RGB)
    for index, frame in enumerate(frames):
        strip.paste(frame, (index * CANVAS, 0))
    return strip.quantize(
        colors=64,
        method=Image.Quantize.MEDIANCUT,
        dither=Image.Dither.NONE,
    )


def save_gif(frames: list[Image.Image], path: Path) -> None:
    palette = build_palette(frames)
    paletted = [
        frame.quantize(palette=palette, dither=Image.Dither.NONE)
        for frame in frames
    ]
    paletted[0].save(
        path,
        save_all=True,
        append_images=paletted[1:],
        duration=FRAME_DURATIONS_MS,
        loop=0,
        disposal=2,
        optimize=False,
    )


def make_contact_sheet(frames: list[Image.Image]) -> Image.Image:
    sheet = Image.new("RGB", (CANVAS * 5, CANVAS * 2), BACKGROUND_RGB)
    for index, frame in enumerate(frames):
        sheet.paste(frame, ((index % 5) * CANVAS, (index // 5) * CANVAS))
    return sheet


def main() -> None:
    if len(sys.argv) not in (3, 4):
        raise SystemExit(
            "usage: build_act01_centerlocked_v11.py SOURCE OUTPUT_DIR [legacy-arc]"
        )

    source_path = Path(sys.argv[1]).resolve()
    output_dir = Path(sys.argv[2]).resolve()
    source_order = (
        LEGACY_CONTINUOUS_ARC_ORDER
        if len(sys.argv) == 4 and sys.argv[3] == "legacy-arc"
        else ROW_MAJOR_ORDER
    )
    transparent_dir = output_dir / "frames_transparent"
    preview_dir = output_dir / "frames_preview"
    check_dir = output_dir / "frames_centerline_check"
    for directory in (transparent_dir, preview_dir, check_dir):
        directory.mkdir(parents=True, exist_ok=True)

    source = Image.open(source_path).convert("RGB")
    raw_cells = [
        chroma_to_rgba(crop_grid_cell(source, index))
        for index in range(GRID_COLUMNS * GRID_ROWS)
    ]
    raw_frames = [raw_cells[index] for index in source_order]

    first_alpha = np.asarray(raw_frames[0])[..., 3]
    first_bbox = foreground_bbox(first_alpha)
    first_body_height = first_bbox[3] - first_bbox[1] + 1
    scale = TARGET_BODY_HEIGHT / first_body_height
    scaled_frames = [scale_full_canvas(frame, scale) for frame in raw_frames]

    transparent_frames: list[Image.Image] = []
    preview_frames: list[Image.Image] = []
    check_frames: list[Image.Image] = []
    metrics: list[dict] = []

    for frame_number, scaled in enumerate(scaled_frames, start=1):
        before = detect_boot_anchor(scaled)
        shift_x = int(round(TARGET_CENTER_X - before["feet_center_x"]))
        shift_y = int(round(TARGET_BASELINE_Y - before["foot_baseline_y"]))
        registered = translate_to_canvas(scaled, shift_x, shift_y)
        after = detect_boot_anchor(registered)

        # A second one-pixel correction handles rounding from half-pixel boot
        # midpoints while preserving nearest-neighbor pixel art.
        correction_x = int(round(TARGET_CENTER_X - after["feet_center_x"]))
        correction_y = int(round(TARGET_BASELINE_Y - after["foot_baseline_y"]))
        if correction_x or correction_y:
            registered = translate_to_canvas(
                registered, correction_x, correction_y
            )
            shift_x += correction_x
            shift_y += correction_y
            after = detect_boot_anchor(registered)

        preview = make_preview(registered, centerline=False)
        check = make_preview(registered, centerline=True)
        transparent_path = transparent_dir / f"ACT01_frame_{frame_number:02d}.png"
        preview_path = preview_dir / f"ACT01_frame_{frame_number:02d}.png"
        check_path = check_dir / f"ACT01_frame_{frame_number:02d}.png"
        registered.save(transparent_path)
        preview.save(preview_path)
        check.save(check_path)

        bbox = foreground_bbox(np.asarray(registered)[..., 3])
        metrics.append(
            {
                "frame": frame_number,
                "duration_ms": FRAME_DURATIONS_MS[frame_number - 1],
                "shift_xy": [shift_x, shift_y],
                "boot_centers_x": [round(value, 2) for value in after["boot_centers_x"]],
                "feet_center_x": round(after["feet_center_x"], 2),
                "centerline_deviation_px": round(
                    after["feet_center_x"] - TARGET_CENTER_X, 2
                ),
                "foot_baseline_y": after["foot_baseline_y"],
                "foreground_bbox": list(bbox),
                "inside_canvas": (
                    bbox[0] >= 0 and bbox[1] >= 0
                    and bbox[2] <= CANVAS - 1 and bbox[3] <= CANVAS - 1
                ),
                "transparent_sha256": sha256(transparent_path),
            }
        )
        transparent_frames.append(registered)
        preview_frames.append(preview)
        check_frames.append(check)

    gif_path = output_dir / "ACT01_斜劈_10帧_50pct中心线锁定_审核版.gif"
    check_gif_path = output_dir / "ACT01_斜劈_10帧_中心线验证.gif"
    save_gif(preview_frames, gif_path)
    save_gif(check_frames, check_gif_path)

    contact_path = output_dir / "ACT01_斜劈_10帧总览_50pct中心线锁定.png"
    check_contact_path = output_dir / "ACT01_斜劈_10帧中心线验证总览.png"
    make_contact_sheet(preview_frames).save(contact_path)
    make_contact_sheet(check_frames).save(check_contact_path)

    deviations = [abs(frame["centerline_deviation_px"]) for frame in metrics]
    report = {
        "source": str(source_path),
        "source_sha256": sha256(source_path),
        "source_dimensions": list(source.size),
        "source_order_zero_based": source_order,
        "canvas": [CANVAS, CANVAS],
        "frame_count": len(metrics),
        "durations_ms": FRAME_DURATIONS_MS,
        "loop_duration_ms": sum(FRAME_DURATIONS_MS),
        "target_body_fill": "50%",
        "target_body_height_px": TARGET_BODY_HEIGHT,
        "source_frame_01_foreground_height_px": first_body_height,
        "uniform_scale_factor": round(scale, 6),
        "reference_definition": "frame 01 midpoint between the two boot centers",
        "target_centerline_x": TARGET_CENTER_X,
        "target_baseline_y": TARGET_BASELINE_Y,
        "max_centerline_deviation_px": max(deviations),
        "all_centerlines_locked": max(deviations) <= 0.5,
        "all_baselines_locked": all(
            frame["foot_baseline_y"] == TARGET_BASELINE_Y for frame in metrics
        ),
        "all_inside_canvas": all(frame["inside_canvas"] for frame in metrics),
        "gif": str(gif_path),
        "gif_sha256": sha256(gif_path),
        "centerline_check_gif": str(check_gif_path),
        "centerline_check_gif_sha256": sha256(check_gif_path),
        "contact_sheet": str(contact_path),
        "contact_sheet_sha256": sha256(contact_path),
        "frames": metrics,
    }
    report_path = output_dir / "ACT01_50pct中心线连续性结构检查.json"
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

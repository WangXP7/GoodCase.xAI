from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np
from PIL import Image


CANVAS_SIZE = 256
GRID_COLUMNS = 5
GRID_ROWS = 2
BACKGROUND_RGB = (231, 225, 214)
TARGET_BASELINE_Y = 224

# The model placed the first accelerating pose at the start of row two.
# Reordering it before the first low-contact pose restores a continuous arc.
# Frame 10 intentionally reuses frame 01 so the loop returns to the exact G0 pose.
SOURCE_ORDER = [0, 1, 2, 3, 5, 4, 6, 7, 8, 0]
# Lock the lower-body root instead of the helmet. This preserves the planted-feet
# illusion while allowing the head and torso to lean naturally through the cut.
TARGET_ROOT_X = [128, 127, 126, 126, 127, 129, 130, 130, 129, 128]
FRAME_DURATIONS_MS = [80, 80, 80, 70, 70, 70, 80, 100, 80, 100]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def chroma_background_mask(rgb: np.ndarray) -> np.ndarray:
    red = rgb[..., 0].astype(np.int16)
    green = rgb[..., 1].astype(np.int16)
    blue = rgb[..., 2].astype(np.int16)
    return (
        (red > 205)
        & (blue > 145)
        & (green < 125)
        & ((red - green) > 95)
        & ((blue - green) > 75)
    )


def foreground_bbox(alpha: np.ndarray) -> tuple[int, int, int, int]:
    ys, xs = np.nonzero(alpha > 0)
    if len(xs) == 0:
        raise RuntimeError("No foreground detected")
    return int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())


def visor_center(rgb: np.ndarray, alpha: np.ndarray) -> tuple[float, float]:
    red = rgb[..., 0]
    green = rgb[..., 1]
    blue = rgb[..., 2]
    orange = (
        (alpha > 0)
        & (red > 175)
        & (green > 55)
        & (green < 210)
        & (blue < 105)
    )
    ys, xs = np.nonzero(orange)
    if len(xs) == 0:
        x0, y0, x1, _ = foreground_bbox(alpha)
        return (x0 + x1) / 2.0, float(y0 + 36)

    # The visor is the densest horizontal amber cluster. Selecting the topmost
    # amber pixel is unreliable because the sword pommel can sit above it.
    row_counts = orange.sum(axis=1)
    peak_y = int(row_counts.argmax())
    yy = np.indices(orange.shape)[0]
    visor_band = orange & (np.abs(yy - peak_y) <= 2)
    band_y, band_x = np.nonzero(visor_band)
    return float(np.median(band_x)), float(np.median(band_y))


def root_center(alpha: np.ndarray) -> float:
    yy, xx = np.indices(alpha.shape)
    _, _, _, baseline_y = foreground_bbox(alpha)
    lower_body = (
        (alpha > 0)
        & (yy >= max(0, baseline_y - 80))
        & (yy <= baseline_y)
        & (xx >= 12)
        & (xx <= 243)
    )
    _, xs = np.nonzero(lower_body)
    if len(xs) == 0:
        x0, _, x1, _ = foreground_bbox(alpha)
        return (x0 + x1) / 2.0
    return float(np.median(xs))


def foot_baseline(alpha: np.ndarray, root_x: float) -> int:
    # In these clean cutouts the lowest foreground pixel is always a planted
    # boot, so using it directly keeps every frame on the exact same floor.
    return foreground_bbox(alpha)[3]


def translate_rgba(image: Image.Image, shift_x: int, shift_y: int) -> Image.Image:
    canvas = Image.new("RGBA", (CANVAS_SIZE, CANVAS_SIZE), (0, 0, 0, 0))
    canvas.alpha_composite(image, (shift_x, shift_y))
    return canvas


def crop_grid_cell(sheet: Image.Image, cell_index: int) -> Image.Image:
    row, column = divmod(cell_index, GRID_COLUMNS)
    left = round(column * sheet.width / GRID_COLUMNS)
    right = round((column + 1) * sheet.width / GRID_COLUMNS)
    top = round(row * sheet.height / GRID_ROWS)
    bottom = round((row + 1) * sheet.height / GRID_ROWS)
    return sheet.crop((left, top, right, bottom))


def prepare_cell(cell: Image.Image, target_root_x: int) -> tuple[Image.Image, dict]:
    resized = cell.convert("RGB").resize(
        (CANVAS_SIZE, CANVAS_SIZE),
        Image.Resampling.NEAREST,
    )
    rgb = np.asarray(resized)
    background = chroma_background_mask(rgb)
    alpha = np.where(background, 0, 255).astype(np.uint8)

    rgba_array = np.dstack((rgb, alpha))
    rgba = Image.fromarray(rgba_array, mode="RGBA")

    before_visor_x, before_visor_y = visor_center(rgb, alpha)
    before_root_x = root_center(alpha)
    before_baseline = foot_baseline(alpha, before_root_x)
    shift_x = int(round(target_root_x - before_root_x))
    shift_y = TARGET_BASELINE_Y - before_baseline
    translated = translate_rgba(rgba, shift_x, shift_y)

    translated_array = np.asarray(translated)
    translated_rgb = translated_array[..., :3]
    translated_alpha = translated_array[..., 3]
    after_visor_x, after_visor_y = visor_center(translated_rgb, translated_alpha)
    after_root_x = root_center(translated_alpha)
    after_baseline = foot_baseline(translated_alpha, after_root_x)
    bbox = foreground_bbox(translated_alpha)

    metrics = {
        "source_visor": [round(before_visor_x, 2), round(before_visor_y, 2)],
        "source_root_x": round(before_root_x, 2),
        "shift": [shift_x, shift_y],
        "visor": [round(after_visor_x, 2), round(after_visor_y, 2)],
        "root_x": round(after_root_x, 2),
        "target_root_x": target_root_x,
        "foot_baseline_y": after_baseline,
        "foreground_bbox": list(bbox),
        "safe_zone_ok": (
            bbox[0] >= 2 and bbox[1] >= 2 and bbox[2] <= 253 and bbox[3] <= 253
        ),
    }
    return translated, metrics


def composite_preview(frame: Image.Image) -> Image.Image:
    background = Image.new("RGBA", frame.size, BACKGROUND_RGB + (255,))
    background.alpha_composite(frame)
    return background.convert("RGB")


def build_global_palette(frames: list[Image.Image]) -> Image.Image:
    strip = Image.new("RGB", (CANVAS_SIZE * len(frames), CANVAS_SIZE), BACKGROUND_RGB)
    for index, frame in enumerate(frames):
        strip.paste(frame, (index * CANVAS_SIZE, 0))
    return strip.quantize(
        colors=64,
        method=Image.Quantize.MEDIANCUT,
        dither=Image.Dither.NONE,
    )


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: build_act01_review_gif.py SOURCE_SHEET OUTPUT_DIR")

    source_path = Path(sys.argv[1]).resolve()
    output_dir = Path(sys.argv[2]).resolve()
    transparent_dir = output_dir / "frames_transparent"
    preview_dir = output_dir / "frames_preview"
    transparent_dir.mkdir(parents=True, exist_ok=True)
    preview_dir.mkdir(parents=True, exist_ok=True)

    sheet = Image.open(source_path).convert("RGB")
    raw_cells = [crop_grid_cell(sheet, index) for index in range(GRID_COLUMNS * GRID_ROWS)]

    transparent_frames: list[Image.Image] = []
    preview_frames: list[Image.Image] = []
    metrics: list[dict] = []

    first_frame: Image.Image | None = None
    first_metrics: dict | None = None

    for frame_number, (source_index, target_x) in enumerate(
        zip(SOURCE_ORDER, TARGET_ROOT_X, strict=True),
        start=1,
    ):
        if frame_number == 10:
            if first_frame is None or first_metrics is None:
                raise RuntimeError("Frame 01 was not initialized")
            transparent = first_frame.copy()
            frame_metrics = dict(first_metrics)
            frame_metrics["exact_g0_repeat_of_frame"] = 1
        else:
            transparent, frame_metrics = prepare_cell(raw_cells[source_index], target_x)
            if frame_number == 1:
                first_frame = transparent.copy()
                first_metrics = dict(frame_metrics)

        preview = composite_preview(transparent)
        transparent_path = transparent_dir / f"ACT01_frame_{frame_number:02d}.png"
        preview_path = preview_dir / f"ACT01_frame_{frame_number:02d}.png"
        transparent.save(transparent_path)
        preview.save(preview_path)

        transparent_frames.append(transparent)
        preview_frames.append(preview)
        frame_metrics.update(
            {
                "frame": frame_number,
                "source_cell": source_index + 1,
                "duration_ms": FRAME_DURATIONS_MS[frame_number - 1],
                "transparent_sha256": sha256(transparent_path),
                "preview_sha256": sha256(preview_path),
            }
        )
        metrics.append(frame_metrics)

    contact_sheet = Image.new("RGB", (CANVAS_SIZE * 5, CANVAS_SIZE * 2), BACKGROUND_RGB)
    for index, frame in enumerate(preview_frames):
        x = (index % 5) * CANVAS_SIZE
        y = (index // 5) * CANVAS_SIZE
        contact_sheet.paste(frame, (x, y))
    contact_path = output_dir / "ACT01_斜劈_10帧总览_5x2.png"
    contact_sheet.save(contact_path)

    palette = build_global_palette(preview_frames)
    paletted_frames = [
        frame.quantize(palette=palette, dither=Image.Dither.NONE)
        for frame in preview_frames
    ]
    gif_path = output_dir / "ACT01_斜劈_10帧_审核版.gif"
    paletted_frames[0].save(
        gif_path,
        save_all=True,
        append_images=paletted_frames[1:],
        duration=FRAME_DURATIONS_MS,
        loop=0,
        disposal=2,
        optimize=False,
    )

    report = {
        "source": str(source_path),
        "source_sha256": sha256(source_path),
        "source_dimensions": list(sheet.size),
        "source_order_zero_based": SOURCE_ORDER,
        "canvas": [CANVAS_SIZE, CANVAS_SIZE],
        "frame_count": len(preview_frames),
        "durations_ms": FRAME_DURATIONS_MS,
        "loop_duration_ms": sum(FRAME_DURATIONS_MS),
        "root_x_sequence": [frame["root_x"] for frame in metrics],
        "max_adjacent_root_step_px": max(
            abs(metrics[index]["root_x"] - metrics[index - 1]["root_x"])
            for index in range(1, len(metrics))
        ),
        "all_baselines_locked": all(
            frame["foot_baseline_y"] == TARGET_BASELINE_Y for frame in metrics
        ),
        "all_safe_zone_ok": all(frame["safe_zone_ok"] for frame in metrics),
        "frame_10_exact_frame_01": (
            metrics[9]["transparent_sha256"] == metrics[0]["transparent_sha256"]
        ),
        "gif": str(gif_path),
        "gif_sha256": sha256(gif_path),
        "contact_sheet": str(contact_path),
        "contact_sheet_sha256": sha256(contact_path),
        "frames": metrics,
    }
    report_path = output_dir / "ACT01_连续性结构检查.json"
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
